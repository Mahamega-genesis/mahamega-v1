
import requests
import config

def send_telegram_message(signal):
    message = f"Signal: {signal['trend']}\nPair: {signal['pair']}\nEntry: {signal['entry']}\nReason: {signal['reason']}\nConfidence: {signal['confidence']}"
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": config.TELEGRAM_CHAT_ID,
        "text": message
    }
    requests.post(url, data=payload)
