
from utils.indicators import calculate_ema, calculate_rsi
from telegram_notify import send_telegram_message
from google_sheet_log import log_signal
import config
import requests

def get_price_data():
    url = "https://api.coingecko.com/api/v3/coins/bitcoin/market_chart"
    params = {
        "vs_currency": "usd",
        "days": "1",
        "interval": "minute"
    }
    response = requests.get(url, params=params)
    data = response.json()
    return [x[1] for x in data['prices']]

def analyze_signal():
    prices = get_price_data()
    ema7 = calculate_ema(prices, 7)
    ema14 = calculate_ema(prices, 14)
    ema28 = calculate_ema(prices, 28)
    rsi = calculate_rsi(prices)

    if ema7[-1] > ema14[-1] > ema28[-1] and rsi[-1] > 50:
        signal = {
            "pair": "BTC/USDT",
            "trend": "Bullish",
            "entry": prices[-1],
            "reason": "EMA crossover + RSI > 50",
            "confidence": "80%"
        }
        send_telegram_message(signal)
        log_signal(signal)

if __name__ == "__main__":
    analyze_signal()
