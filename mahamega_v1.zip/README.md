# Mahamega V1
Sistem sinyal trading otomatis menggunakan EMA, RSI, dan integrasi Telegram & Google Sheets.