
def log_signal(signal):
    print("Signal logged:", signal)  # Placeholder
